# Online Shopping Cart
A web based shopping cart developed in Java and MySQL.

This is an typical shopping cart appication, having various features like user/admin login, session management, cart total, etc. Uses SQL database to store various information.

This was developed as part of academics to mainly have insights on Java Enterprise Edition, SQL databases, and Session management in Java.
